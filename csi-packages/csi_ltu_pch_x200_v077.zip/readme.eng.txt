   Lightweight Linux utility package for Popcorn Hour C-200/A-200/A-210 media players from Padavan
                                   Linux Term Utils (LTU) v0.7.7


* INTRODUCTION *

This package includes the following utilities:
- busybox-1.17.4 (only additional applets not included in the original busybox)
- dropbear-0.52-1 (lightweight ssh-server)
- mc-4.7.5.5 (a powerful filemanager Midnight Commander)
- nano-2.2.6 (a powerful text editor)
- screen-4.0.3 (a terminal extender)
- nut-2.4.3 (Network UPS Tools)
- aria2-1.11.1 (multi-protocol download utility)
- microdc2-0.15.6-7 (console DC++ client)
- e2fsprogs-1.41.12 (utilities for managing ext2/3 file systems)
- util-linux-ng-2.19.1 (fdisk, blkid)
- parted-3.0 (an alternative utility for HDD partitioning with GPT support)
- smartmontools-5.41 (HDD S.M.A.R.T. control)
- hdparm-9.37 (HDD management)
- usbutils-0.87 (lsusb applet)
- paragon ntfs/hfs tools (chkntfs, chkhfs)

This package also includes updates for NMT applications:
- transmission-daemon-2.42 (new version for NMT)
- pure-ftpd-1.0.29 (new version for NMT)

The package includes the missing PTY module (a pseudo-terminal device driver) which has been removed from 
Linux kernel by Sybas due to licensing limitations. Without PTY it�s impossible to run such terminals as 
Telnet or SSH. This module has been compiled by woj (http://code.google.com/p/popcorn-bld/) as a bootable 
kernel module and allows running PTY without recompiling the kernel.

The package has been compiled using Sourcery mips-linux-gnu v4.3-154 cross-compiler under Debian Linux 6.0.2 
with the following options: 
-march=74kf2_1 -mtune=74kf2_1 -mdspr2
which results in maximum code optimization for Sigma SMP864X processors.


* INSTALLATION AND UPDATE *

This package has the NMT CSI format and must be installed using the NMT CSI Installer 
(http://www.nmtinstaller.com/) from PC. Before run NMT CSI Installer, make sure NMT application "FTP server" 
is on.

If the NMT applications were installed on a USB pen drive, you need to choose a Hardware with suffix "(USB)" 
in the NMT CSI Installer.

To install the package you must select menu "File"> "Install from file" in the NMT CSI Installer and specify 
the path to the zip archive with this package. The package will be installed to standard path /share/Apps in 
the directory /share/Apps/LTU.

The package includes a script which automatically changes the configuration of the Apache server included 
in NMT apps. By default Apache runs 6 processes plus 6 more when myiHome server is running and expects 150+150 
incoming connections. The script limits the number of processes to 2 and reduces the number of available 
connections to 5 in order to save player�s RAM and CPU resources. The new Apache configuration will be applied 
after rebooting a player. This configuration change is an alternative to questionable installation of the 
third-party lighttpd server instead of Apache which is proposed by CSI installer to reduce player�s resources 
utilization.


* CONFIGURATION *

You can edit the configuration file /share/Apps/LTU/configure and turn off the utilities you don�t need. 
Warning! The config file is in Unix format so you need to use an editor that respects Unix line endings (LF), 
e.g. notepad2 or FAR built-in editor.

By enabling the START_LOGGER=1(or 2) config option you can start a logger to register all system and kernel 
events in the file "messages" which can be accessed via SAMBA at the path /share/Apps/LTU/log.

To automatically start the custom user commands is purposed the script file 
/share/Apps/LTU/user.scripts/on_start_nmt.sh.

You need to restart CSI application "LTU" via NMT CSI Installer after changing configuration.


* TERMINAL CONNECTION *

If you set the option TERMINAL_SERVER=1 in the /share/Apps/LTU/configure file, after starting the package a 
player receives telnet connections at the standard port 23. Telnet supports up to 4 concurrent terminal sessions. 
If you set the option TERMINAL_SERVER=2 a player receives SSH connections at the standard port 22.

To access a player via Telnet you can use the Microsoft telnet client but it�s better to use PuTTY terminal client 
(http://www.chiark.greenend.org.uk/~sgtatham/putty). It also has a SSH client. Don't forget to choose the UTF-8 
character encoding before connecting to a player to display international characters properly. After connecting 
you will be prompted for a login � type "root". The root password is defined by PASSWD_ROOT= setting. It's 
mandatory when using SSH-server. Also you can generate your own rsa and dss keys for the SSH server if necessary 
with "dropbearkeynew" shell command. The new SSH security keys will be applied after rebooting a player.

If you use Lundmann Shell, it can be uninstalled � it's no longer necessary now when you have a full-featured 
terminal server.


* LIMITATIONS *

ATTENTION! 
Before installing the package it�s strongly recommended to uninstall the following packages with NMT CSI (if installed):
- busybox (Ger Teunis)
- Telnet (Vaidyasr)
Then you need to reboot your player.

This package has been tested on the latest firmwares 
C-200:
 "03-04-110530-21-POP-408"
 "02-04-110422-21-POP-408"
 "02-04-110308-21-POP-408"
 "02-04-101206-21-POP-408"
 "02-04-101104-21-POP-408"
 "02-03-101006-21-POP-408"
 "02-03-100821-21-POP-408"
 "02-02-100428-19-POP-408"
A-200/A-210:
 "02-04-110519-21-POP-411"
 "02-04-110308-21-POP-411"
 "02-04-101208-21-POP-411"
 "02-04-101106-21-POP-411"
 "02-03-100918-21-POP-411"
Not guaranteed to work package on earlier firmware versions. The package doesn�t write any data in on-board NAND Flash 
and after being disabled or uninstalled it doesn�t leave any traces in Linux root partition.


* CHANGE HISTORY *

v0.7.7 (10/22/2011):
- Updated NMT torrent Transmission to v2.42.
- Updated Midnight Commander to v4.7.5.5.
- Updated smartmontools to v5.41.
- Fixed PTY load for old firmwares.

v0.7.6 (07/25/2011):
- Updated NMT torrent Transmission to v2.33.
- Updated hdparm to v9.37.

v0.7.5 (07/10/2011):
- Updated NMT torrent Transmission to v2.32.
- Updated util-linux-ng to v2.19.1.
- Updated GNU Parted to v3.0.
- Added support SFTP protocol (SSH FTP) for Dropbear.
- Added auto backup XENV.
- Added script "backup_nand" for manual create NAND flash backups.
- Transmission RPC port changed to 9091.

v0.7.4 (05/19/2011):
- Updated NMT torrent Transmission to v2.31.
- Updated Aria2 to v1.11.1 (with support incompleted downloads list).
- Updated Midnight Commander to v4.7.5.2.
- Added automatic TCP receive window fix before start Transmission, Aria2, MicroDC2. FIX_TCP_RMEM param is deprecated.
- Added automatic conversion file "configure" to UNIX format.
- Added workaround for SMB workgroup (bug in last firmwares).
- Added force Telnet startup for workaround syb_famework deadlock on start firmware update (bug in last firmwares).
- Added sendmail applet in busybox.

v0.7.3 (01/24/2011):
- Added configuration for start aria2 as XML-RPC server.
- Set environment value "HOME=/usr/ltu/home", applications settings will be stored after reboot.

v0.7.2 (01/11/2011):
- Added scripts for microdc2 background run.
- Added auto-generate settings.json on NMT transmission update.

v0.7.1 (01/10/2011):
- Added support locale and nls.
- The ncurses library replaced by ncursesw.
- Added support UTF-8 for nano editor.
- Added Russian and Ukrainian localization for mc, nano, microdc2, aria2.
- Fixed national symbols issue in microdc2, added microdc2-slave-mode.patch and microdc2-ru.patch.

v0.7 (01/08/2011):
- Package implemented into new destination /share/Apps/LTU with Linux rootfs rule.
- User scripts moved to destination dir /share/Apps/LTU/user.scripts.
- Added update for NMT FTP server pure-ftpd v1.0.29 (replace old NMT pure-ftpd v1.0.21).
- Added package Network UPS Tools (NUT) v2.4.3.
- Added utility aria2 v1.10.8 (multi-protocol download utility).
- Added utility microdc2 v0.15.6 (DC++ client).
- Added direct patch for setups.cgi (disable tcp_rmem background changes).
- Now value FIX_TCP_RMEM=1 uses large fixed tcp_rmem buffer for increase NFS-TCP read (from 72 to 94 Mbit/s).
- Increase socket read buffer size (rmem_max � rmem_default) to 0.5MB for buffering IP stream (e.g. IPTV, Radio, YouTube).
- Process transmission-daemon now running with user nmt rights.
- Added spindown timer for any HDD (default idle 20 minutes), sets AAM quiet mode and disable APM (LCC workaround). 
- Disabled forced HDD spindown by pressing the Power button (workaround stop-start-stop).
- Added support firmwares from 07.05.2010 (and earler) with Linux kernel 2.6.22.19-19-4.

v0.6.6 (12/22/2010):
- Added kernel TCP receive window fix, for prevent kernel bug (sheduling while atomic) on fast bittorrent downloads.
- Added update for NMT bittorent client transmission-daemon 2.13 (replace old NMT transmission 1.76).
- Fixed SSH keys reset after package update.

v0.5 (12/09/2010):
- Fixed compatibility issue with �-200 firmware "02-04-101206-21-POP-408".

v0.4 (11/30/2010):
- Fixed GNU screen terminal issue.
- SSH server dropbear now installed into rootfs.
- Added terminal login for user "nmt".
- Added third-party utils for checking (fsck) FAT, FAT32, NTFS, HFS, HFS+ filesystems.
- Added selector for system log destination.
- Added shell script "copy_to_rootfs.sh" for temporary copy important utils to rootfs.
- Fixed conflict with Popcorn OSD after perform clean NMT installation.

v0.3 (11/18/2010):
- Added GNU screen v4.0.3.
- Fixed shell script "dropbearkeynew" under telnet call.
- Improved load PTY module (up to 25x time faster).
- The package now compatible with NMT CSI format.

v0.2 (11/12/2010):
- Added file manager Midnight Commander v4.7.0.10.
- Added smartd logger from smartmontools v5.40.
- Updated dropbear ssh server to v0.52, added shell script "dropbearkeynew".
- Updated nano editor to v2.2.5.
- Improved CSI package startup script.
- Added custom user script "user.script.sh".

v0.1 (11/8/2010):
- First release.


-
10/22/2011
Padavan
